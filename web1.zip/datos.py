productos = [
  {'nombre': 'Celular', 'precio': 1250},
  {'nombre': 'Computador', 'precio': 2150},
  {'nombre': 'Tablet', 'precio': 875},
  {'nombre': 'Consola', 'precio': 1650},
  {'nombre': 'Lapiz', 'precio': 5},
  {'nombre': 'Borrador', 'precio': 1.2},
  {'nombre': 'Sacapuntas', 'precio': 2.5},
]